<?php

 $con = mysqli_connect("localhost", "root", "", "webcam");

if(isset($_POST['submit'])){
       
		$email = $_POST['email'];
		$password = $_POST['pass'];

		$q = "SELECT * FROM users WHERE email = '$email'&& password = '$password'";
		$result = mysqli_query($con, $q);
		
		$num = mysqli_num_rows($result);
		
		if($num == 1)
		{			
			header('location: cam.php');
		}
		else
		{
			
				header('location: login.php');
		}
}
?>	



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FARMER ASSISTANT</title>
<style>
    .one
    {
        margin: 3% 30%;
		border:2px solid green;       
		text-align: center;		
		color:green;
		background-color:black;	
        border-radius: 15px;
   }
    .one h1{
        line-height: 100px;
    }
    .one:hover{
        background-color: aqua;
        color: blue;
    }
    
    .two
    {
        border: 2px solid green;
        text-align: center;
        margin: 0% 30%;
        background-color: aqua;
        text-transform: uppercase;
        border-radius: 15px;        
    }
    .two:hover{
        background-color: black;
        color: green;
    }
    .two form input{
        margin-bottom: 20px;
        padding: 15px;
        border-radius: 20px;
        width: 300px;
        background: blue;
       border: 2px solid black; 
    }
    .two form input[type="submit"]{
        width:150px;
        background: orange;
        font-size: 20px;
        padding: 10px;
    }
    .two form input[type="submit"]:hover{
        background-color: aqua;
    }
</style>
</head>
<body>
    <div class="one">
        <h1>FARMER ASSISTANT</h1>
    </div>
    <div class="two">
        <h2>Login Form</h2><br>
        <form method="POST" action="">    
            <input type="email" name="email" placeholder="Email" /><br>
            <input type="password" name="pass" placeholder="Password" /><br>
            <input type="submit" value="LOG IN" name="submit" />
        </form>
    </div>
</body>
</html>